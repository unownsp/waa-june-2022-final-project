package alumnimanagement.services.impl;public class UserServiceImpl {
}
