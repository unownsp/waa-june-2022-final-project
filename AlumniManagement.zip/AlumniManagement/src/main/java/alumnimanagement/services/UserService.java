package alumnimanagement.services;

public interface UserService {
}
