package alumnimanagement.controller;

public class UserController {
}
