package alumnimanagement.repo;

public class UserRepo {
}
