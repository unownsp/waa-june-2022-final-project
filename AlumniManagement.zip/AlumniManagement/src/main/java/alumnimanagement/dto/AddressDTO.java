package alumnimanagement.dto;

import lombok.Data;

@Data
public class AddressDTO {

    private String state;
    private String city;
}
