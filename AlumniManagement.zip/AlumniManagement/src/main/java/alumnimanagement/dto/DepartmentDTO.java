package alumnimanagement.dto;

public class DepartmentDTO {
    private String departmentName;
}
