package alumnimanagement.dto;

public class ReportList {
    public Long value;
    public String name;
}
