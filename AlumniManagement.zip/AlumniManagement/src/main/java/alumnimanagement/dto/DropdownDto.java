package alumnimanagement.dto;

import lombok.Data;

@Data
public class DropdownDto {
    private Long id;
    private String title;
}
